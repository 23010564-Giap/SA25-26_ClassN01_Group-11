-- Tạo bảng khoa
CREATE TABLE IF NOT EXISTS khoa (
  id INT AUTO_INCREMENT PRIMARY KEY,
  maKhoa VARCHAR(50) NOT NULL,  -- Mã Khoa
  tenKhoa VARCHAR(255) NOT NULL,  -- Tên Khoa
  truong VARCHAR(255) NOT NULL,  -- Thuộc trường
  ngayThanhLap DATE NOT NULL,  -- Ngày thành lập
  trangThai ENUM('Hoạt động', 'Ngừng hoạt động') DEFAULT 'Hoạt động',  -- Trạng thái khoa
  CONSTRAINT uc_maKhoa UNIQUE (maKhoa)  -- Thêm chỉ mục duy nhất cho mã khoa
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Tạo bảng nganh
CREATE TABLE IF NOT EXISTS nganh (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenNganh VARCHAR(255) NOT NULL,
  khoa_id INT NOT NULL,
  CONSTRAINT fk_nganh_khoa FOREIGN KEY (khoa_id) REFERENCES khoa(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tạo bảng giangvien
CREATE TABLE IF NOT EXISTS giangvien (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenGiangVien VARCHAR(255) NOT NULL,
  khoa_id INT NOT NULL,
  CONSTRAINT fk_gv_khoa FOREIGN KEY (khoa_id) REFERENCES khoa(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tạo bảng news
CREATE TABLE IF NOT EXISTS news (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  date DATE NOT NULL,
  category ENUM('phongdambao','phongdaotao','khac') DEFAULT 'khac'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Thêm dữ liệu mẫu vào bảng news
INSERT INTO news(title, content, date, category) VALUES
('Thông báo A','Nội dung A', CURDATE(),'phongdambao'),
('Thông báo B','Nội dung B', CURDATE(),'phongdaotao');
